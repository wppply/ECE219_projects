# ECE219_projects
- All the code are in the scratchBook.ipynb
- open with jupyter notebook with packages included in the requirements.txt
- Because the code order and imported packages are not well organized. please run every problem from beginning if something is missing.
- For problem a-i, each problem code start from the markdown title of itself. 
- To change NMF<->LSI please change 'NMF_deduction'<-> 'LSI_deduction'  dimension reduction function. 
- To change df_min, plz change the parameters of 'TF_builder' in line



